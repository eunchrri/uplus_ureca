package com.uplus.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrecaBookManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(UrecaBookManagementApplication.class, args);
	}

}
