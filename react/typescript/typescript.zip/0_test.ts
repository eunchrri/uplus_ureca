let test: string = 'hello'
console.log('test:', test)
let test3: number = 100
console.log('test3:',test3)