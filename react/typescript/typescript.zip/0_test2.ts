let test2: string = 'hello'
console.log('test:',test)